<?php get_header(); ?>
<main>
  <div class="contents">
    <div class="post-all">


      <!-- if():
        endif;

        if(){
        } -->

      <?php if (have_posts()): ?>
        <?php while (have_posts()): ?>
          <?php the_post(); ?>
          <article id="post-<?php the_ID(); ?>" <?php post_class('post'); ?>>
            <img src="<?php echo get_theme_file_uri('/images/pic_post01.jpg'); ?>" alt="">
            <h2 class="post-title"><?php the_title(); ?></h2>
            <p class="post-date"><?php the_time('Y/n/d[D]'); ?></p>
            <div class="post-contents">
              <?php the_excerpt(); ?>
            </div>
            <a class="post-btn" href="<?php the_permalink(); ?>">続きを読む</a>
            <div class="post-info">
              <ul>
                <li class="post-category">Category: <?php echo get_the_category_list('/'); ?></li>
                <li class="post-tag">Tag: <?php echo get_the_tag_list('', '/'); ?></li>
              </ul>
            </div>
          </article>
        <?php endwhile; ?>
      <?php else: ?>
        <p>記事がありません。</p>
      <?php endif; ?>

      <div class="nav-page">
        <ul>
          <li><?php previous_posts_link('←前の10件'); ?></li>
          <li><?php next_posts_link('次の10件→'); ?></li>
        </ul>
      </div>

      <div class="nav-page">
        <?php the_posts_pagination(
          array(
            'prev_text' => '<',
            'next_text' => '>',
            'type' => 'list'
          )
        ); ?>
      </div>

      <div class="nav-page">
        <ul>
          <li><a href="#">&lt;</a></li>
          <li><a href="#">1</a></li>
          <li><a href="#">2</a></li>
          <li><a href="#">3</a></li>
          <li><a href="#">4</a></li>
          <li><a href="#">&gt;</a></li>
        </ul>
      </div>
    </div>
    <div class="sidebar">
      <?php get_sidebar(); ?>
    </div>
  </div>
</main>
<?php get_footer(); ?>
