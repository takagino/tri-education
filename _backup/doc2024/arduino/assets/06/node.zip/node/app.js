const http = require("http");
const fs = require("fs");

const hostname = "127.0.0.1";
const port = 3000;

const index = fs.readFileSync("./index.html", "utf-8");
const about = fs.readFileSync("./about.html", "utf-8");
const style = fs.readFileSync("./style.css", "utf-8");
const image = fs.readFileSync("./sample.png");

const server = http.createServer((req, res) => {
  const pathName = req.url;

  if (pathName === "/") {
    res.writeHead(200, { "Content-type": "text/html" });
    res.end(index);
  } else if (pathName === "/about") {
    res.writeHead(200, { "Content-type": "text/html" });
    res.end(about);
  } else if (pathName === "/style.css") {
    res.writeHead(200, { "Content-type": "text/css" });
    res.end(style);
  } else if (pathName === "/sample.png") {
    res.writeHead(200, { "Content-type": "image/png" });
    res.end(image);
  } else {
    res.writeHead(
      404
    ); /* 404は「リクエストされたリソースを見つけることができない時のレスポンスコード」*/
    res.end("Not Found...");
  }
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}`);
});
